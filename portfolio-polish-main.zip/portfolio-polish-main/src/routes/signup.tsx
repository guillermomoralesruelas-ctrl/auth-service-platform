import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Lock, User, Eye, EyeOff } from "lucide-react";

export const Route = createFileRoute("/signup")({
  component: SignupPage,
  head: () => ({
    meta: [
      { title: "Sign up — Portfolio" },
      { name: "description", content: "Create your portfolio account." },
    ],
  }),
});

function GoogleIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  );
}

function SignupPage() {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  return (
    <main className="min-h-dvh bg-[#0a0a14] flex items-center justify-center px-6 py-12 relative overflow-hidden font-sans">
      {/* Aurora glows */}
      <div className="pointer-events-none absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-violet-600/30 rounded-full blur-[120px]" />
      <div className="pointer-events-none absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-cyan-500/20 rounded-full blur-[120px]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,transparent_0%,#0a0a14_70%)]" />

      {/* Grid texture */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      <div className="relative w-full max-w-[400px]">
        <div className="backdrop-blur-2xl bg-white/[0.03] border border-white/10 rounded-2xl p-8 shadow-2xl shadow-black/40">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 p-[1.5px]">
              <div className="w-full h-full rounded-[10px] bg-[#0a0a14] flex items-center justify-center">
                <div className="w-4 h-4 rounded-sm bg-gradient-to-br from-violet-400 to-cyan-300" />
              </div>
            </div>
          </div>

          <h1 className="text-2xl font-semibold text-white text-center tracking-tight mb-1.5">
            Create your account
          </h1>
          <p className="text-sm text-zinc-400 text-center mb-7">
            Join the platform today
          </p>

          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); navigate({ to: "/dashboard" }); }}>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="firstName" className="text-xs font-medium text-zinc-300 mb-1.5 block">
                  First name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                  <input
                    id="firstName"
                    type="text"
                    placeholder="Jane"
                    className="w-full pl-9 pr-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-violet-400/50 focus:bg-white/[0.05] focus:ring-2 focus:ring-violet-500/20 transition"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="lastName" className="text-xs font-medium text-zinc-300 mb-1.5 block">
                  Last name
                </label>
                <input
                  id="lastName"
                  type="text"
                  placeholder="Doe"
                  className="w-full px-3 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-violet-400/50 focus:bg-white/[0.05] focus:ring-2 focus:ring-violet-500/20 transition"
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="text-xs font-medium text-zinc-300 mb-1.5 block">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  id="email"
                  type="email"
                  placeholder="name@company.com"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-violet-400/50 focus:bg-white/[0.05] focus:ring-2 focus:ring-violet-500/20 transition"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="text-xs font-medium text-zinc-300 mb-1.5 block">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="At least 8 characters"
                  className="w-full pl-9 pr-10 py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-violet-400/50 focus:bg-white/[0.05] focus:ring-2 focus:ring-violet-500/20 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-gradient-to-r from-violet-500 to-cyan-400 text-white rounded-lg text-sm font-semibold hover:opacity-90 shadow-lg shadow-violet-500/30 transition"
            >
              Create account
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="h-px bg-white/10 flex-1" />
            <span className="text-xs text-zinc-500">OR</span>
            <div className="h-px bg-white/10 flex-1" />
          </div>

          <button
            type="button"
            className="w-full py-2.5 bg-white/[0.03] border border-white/10 rounded-lg text-sm font-medium text-white hover:bg-white/[0.06] hover:border-white/20 flex items-center justify-center gap-2.5 transition"
          >
            <GoogleIcon />
            Continue with Google
          </button>

          <p className="text-[11px] text-zinc-500 text-center mt-5 leading-relaxed">
            By creating an account, you agree to our{" "}
            <a href="#" className="text-zinc-300 hover:text-white underline-offset-2 hover:underline">Terms</a>{" "}
            and{" "}
            <a href="#" className="text-zinc-300 hover:text-white underline-offset-2 hover:underline">Privacy Policy</a>.
          </p>
        </div>

        <p className="text-xs text-zinc-500 text-center mt-6">
          Already have an account?{" "}
          <Link to="/" className="text-white hover:underline font-medium">
            Sign in
          </Link>
        </p>

        <p className="text-[10px] text-zinc-600 text-center mt-8 tracking-[0.2em]">
          PROTECTED BY AES-256 ENCRYPTION
        </p>
      </div>
    </main>
  );
}
